export function metrics(data,s){
 const crf=s.rate===0?1/s.life:s.rate*(1+s.rate)**s.life/((1+s.rate)**s.life-1);
 const output=s.cement.map(a=>a.reduce((x,y)=>x+y,0));
 const production=s.clinker.map((a,i)=>a.reduce((x,y)=>x+y,0)+s.factor*output[i]);
 let capex=0,opex=0,limestone=0,cementTonKm=0,clinkerTonKm=0,kcap=0,gcap=0;
 const facilities=data.sites.map((site,i)=>{const mod=data.modules[site.type][s.modules[i]]; if(!mod)return {...site,module:'Closed',output:0,grindUtil:0,clinkerUtil:0};capex+=mod.capex;opex+=mod.opex;gcap+=mod.grinding;kcap+=mod.clinker||0;return {...site,module:mod.name,grinding:mod.grinding,clinkerCapacity:mod.clinker||0,output:output[i],production:production[i]||0,grindUtil:output[i]/mod.grinding,clinkerUtil:mod.clinker?production[i]/mod.clinker:0};});
 s.cement.forEach((a,i)=>a.forEach((x,j)=>cementTonKm+=x*data.cementDistances[i][j]));s.clinker.forEach((a,i)=>a.forEach((x,j)=>clinkerTonKm+=x*data.clinkerDistances[i][j]));production.forEach((x,i)=>limestone+=x*1.5*data.sites[i].limestone*.1);
 const costs=[capex*crf,opex,limestone,cementTonKm*s.cementRate*.1,clinkerTonKm*s.clinkerRate*.1]; const demand=s.demand.reduce((a,b)=>a+b,0),clinkerShipped=s.clinker.flat().reduce((a,b)=>a+b,0);
 const errors=[];s.demand.forEach((v,j)=>{if(Math.abs(s.cement.reduce((a,row)=>a+row[j],0)-v)>1e-5)errors.push('Demand '+data.markets[j].id);});
 for(let j=0;j<4;j++)if(Math.abs(s.clinker.reduce((a,row)=>a+row[j],0)-s.factor*output[j+6])>1e-5)errors.push('Clinker balance G'+(j+1));
 facilities.forEach((f,i)=>{if(Math.max(f.grindUtil,f.clinkerUtil)>s.utilization+1e-5)errors.push('Capacity '+f.id);if(s.modules[i]<0&&(output[i]>1e-5||(production[i]||0)>1e-5))errors.push('Closed site '+f.id);if(s.unavailable.includes(f.id)&&s.modules[i]>=0)errors.push('Unavailable '+f.id);});
 s.cement.forEach((a,i)=>a.forEach((v,j)=>{if(v< -1e-6||v>1e-6&&data.cementDistances[i][j]>s.cementLimit)errors.push('Cement lane');}));s.clinker.forEach((a,i)=>a.forEach((v,j)=>{if(v< -1e-6||v>1e-6&&data.clinkerDistances[i][j]>s.clinkerLimit)errors.push('Clinker lane');}));
 return {facilities,costs,total:costs.reduce((a,b)=>a+b,0),capex,kcap,gcap,demand,cementLead:cementTonKm/demand,clinkerLead:clinkerShipped?clinkerTonKm/clinkerShipped:0,clinkerShipped,errors,crf};
}
export function validateScenario(data,s,fixed){
 const limits={cementRate:[0,20],clinkerRate:[0,20],utilization:[.01,1],cementLimit:[0,5000],clinkerLimit:[0,5000],factor:[.01,1],rate:[0,.5],life:[1,100]};
 for(const [key,[min,max]] of Object.entries(limits))if(!Number.isFinite(s[key])||s[key]<min||s[key]>max)throw Error('Invalid '+key+': expected '+min+' to '+max+'.');
 if(!Number.isInteger(s.life))throw Error('Asset life must be a whole number.');
 if(!Array.isArray(s.demand)||s.demand.length!==data.markets.length||s.demand.some(v=>!Number.isFinite(v)||v<0||v>100)||s.demand.reduce((a,b)=>a+b,0)<=0)throw Error('Enter valid nonnegative market demand with a positive total.');
 if(!Array.isArray(s.unavailable)||s.unavailable.some(id=>!data.sites.some(site=>site.id===id)))throw Error('Invalid unavailable facility.');
 if(s.moduleChoices&&(s.moduleChoices.length!==data.sites.length||s.moduleChoices.some(v=>!['auto','-1','0','1','2'].includes(String(v)))))throw Error('Invalid module choice.');
 if(fixed&&(fixed.length!==data.sites.length||fixed.some(v=>![-1,0,1,2].includes(v))))throw Error('Invalid fixed modules.');
}
export function buildLP(data,s,fixed){
 validateScenario(data,s,fixed);
 const terms=a=>a.filter(([c])=>Math.abs(c)>1e-12).map(([c,n],i)=>(c<0?' - ':i?' + ':' ')+Math.abs(c)+' '+n).join('')||' 0 y0_0';
 const obj=[],rows=[],bounds=[],binaries=[];const crf=s.rate===0?1/s.life:s.rate*(1+s.rate)**s.life/((1+s.rate)**s.life-1);
 for(let i=0;i<10;i++){
 const mods=data.modules[data.sites[i].type];rows.push('site'+i+':'+terms(mods.map((m,k)=>[1,`y${i}_${k}`]))+' <= 1');
 mods.forEach((m,k)=>{const n=`y${i}_${k}`;obj.push([m.capex*crf+m.opex,n]);binaries.push(n);if(s.unavailable.includes(data.sites[i].id))bounds.push(n+' = 0');else if(fixed)bounds.push(n+' = '+(fixed[i]===k?1:0));else if(s.moduleChoices&&s.moduleChoices[i]!=='auto')bounds.push(n+' = '+(Number(s.moduleChoices[i])===k?1:0));});
 const grind=[];for(let j=0;j<12;j++){const n=`x${i}_${j}`;grind.push([1,n]);obj.push([.1*data.cementDistances[i][j]*s.cementRate+(i<6?.1*1.5*data.sites[i].limestone*s.factor:0),n]);bounds.push(n+(data.cementDistances[i][j]>s.cementLimit?' = 0':' >= 0'));}
 rows.push('grind'+i+':'+terms([...grind,...mods.map((m,k)=>[-s.utilization*m.grinding,`y${i}_${k}`])])+' <= 0');
 if(i<6){const cap=grind.map(([c,n])=>[s.factor,n]);for(let j=0;j<4;j++){const n=`z${i}_${j}`;cap.push([1,n]);obj.push([.1*(data.clinkerDistances[i][j]*s.clinkerRate+1.5*data.sites[i].limestone),n]);bounds.push(n+(data.clinkerDistances[i][j]>s.clinkerLimit?' = 0':' >= 0'));}rows.push('clinkercap'+i+':'+terms([...cap,...mods.map((m,k)=>[-s.utilization*m.clinker,`y${i}_${k}`])])+' <= 0');}
 }
 for(let j=0;j<12;j++)rows.push('demand'+j+':'+terms(data.sites.map((_,i)=>[1,`x${i}_${j}`]))+' = '+s.demand[j]);
 for(let j=0;j<4;j++)rows.push('balance'+j+':'+terms([...Array.from({length:6},(_,i)=>[1,`z${i}_${j}`]),...Array.from({length:12},(_,k)=>[-s.factor,`x${j+6}_${k}`])])+' = 0');
 return 'Minimize\n cost:'+terms(obj)+'\nSubject To\n '+rows.join('\n ')+'\nBounds\n '+bounds.join('\n ')+'\nBinary\n '+binaries.join(' ')+'\nEnd';
}
export function decode(data,s,r){if(!Number.isFinite(r.ObjectiveValue))throw Error('Invalid objective.');const v=n=>{const x=r.Columns[n]?.Primal;if(!Number.isFinite(x))throw Error('Missing or invalid solution variable '+n);return Math.abs(x)<1e-8?0:x;};return {...s,modules:data.sites.map((_,i)=>[0,1,2].find(k=>v(`y${i}_${k}`)>.5)??-1),cement:data.sites.map((_,i)=>data.markets.map((_,j)=>v(`x${i}_${j}`))),clinker:Array.from({length:6},(_,i)=>Array.from({length:4},(_,j)=>v(`z${i}_${j}`))),solverStatus:r.Status,objective:r.ObjectiveValue};}
